#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ドローン信号解析GUI
リアルタイム周波数スペクトラム表示
"""

import tkinter as tk
from tkinter import ttk, messagebox
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.animation import FuncAnimation
import matplotlib.font_manager as fm
import numpy as np
import serial
import threading
import time
import pygame
from collections import deque
import queue

# 日本語フォント設定
plt.rcParams['font.family'] = ['DejaVu Sans', 'Arial', 'sans-serif']
plt.rcParams['axes.unicode_minus'] = False

class SpectrumAnalyzer:
    def __init__(self, root):
        self.root = root
        self.root.title("🛡️ ドローン信号解析GUI - セキュリティ研究用")
        self.root.geometry("1200x800")
        
        # データ管理
        self.channels = 125
        self.frequencies = np.arange(2400, 2525)  # numpy配列で高速化
        self.spectrum_data = np.zeros(self.channels)
        self.highlight_freq = None
        self.data_buffer = deque(maxlen=30)  # バッファサイズ削減 100→30

        # ウォーターフォール用データ - 軽量化
        self.waterfall_height = 100  # 時間軸の高さ削減 200→100
        self.waterfall_data = np.zeros((self.waterfall_height, self.channels))
        self.spectrum_history = deque(maxlen=self.waterfall_height)
        self.waterfall_update_counter = 0  # 更新頻度制御用
        
        # シリアル通信
        self.serial_port = None
        self.serial_thread = None
        self.is_connected = False
        self.data_queue = queue.Queue(maxsize=50)  # 高速データ処理用キュー
        
        # コントローラー
        self.joystick = None
        self.pygame_initialized = False
        
        # GUI作成
        self.setup_gui()
        self.setup_plot()
        self.init_gamepad()
        
        # アニメーション開始 - 軽量化のため更新頻度を下げる
        self.animation = FuncAnimation(
            self.fig, self.update_plot, interval=100, blit=True
        )
        
    def setup_gui(self):
        """GUI構築"""
        # メインフレーム
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 上部コントロールパネル
        control_frame = ttk.LabelFrame(main_frame, text="🎮 制御パネル", padding=10)
        control_frame.pack(fill=tk.X, pady=(0, 10))
        
        # シリアルポート設定
        ttk.Label(control_frame, text="COMポート:").grid(row=0, column=0, padx=5)
        self.port_var = tk.StringVar(value="COM10")
        port_combo = ttk.Combobox(control_frame, textvariable=self.port_var, 
                                  values=["COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9", "COM10", "COM11", "COM12"])
        port_combo.grid(row=0, column=1, padx=5)
        
        # 接続ボタン
        self.connect_btn = ttk.Button(control_frame, text="接続", 
                                      command=self.toggle_connection)
        self.connect_btn.grid(row=0, column=2, padx=10)
        
        # ステータス表示
        self.status_var = tk.StringVar(value="🔴 未接続")
        ttk.Label(control_frame, textvariable=self.status_var).grid(row=0, column=3, padx=20)
        
        # コントローラー情報
        self.controller_var = tk.StringVar(value="🎮 コントローラー: 未検出")
        ttk.Label(control_frame, textvariable=self.controller_var).grid(row=0, column=4, padx=20)
        
        # 情報パネル
        info_frame = ttk.LabelFrame(main_frame, text="📊 解析情報", padding=10)
        info_frame.pack(fill=tk.X, pady=(0, 10))
        
        # 周波数情報
        self.freq_info_var = tk.StringVar(value="注目周波数: なし")
        ttk.Label(info_frame, textvariable=self.freq_info_var, font=("Arial", 12, "bold")).pack()
        
        # グラフフレーム
        self.plot_frame = ttk.LabelFrame(main_frame, text="📡 リアルタイム周波数スペクトラム", padding=5)
        self.plot_frame.pack(fill=tk.BOTH, expand=True)
        
    def setup_plot(self):
        """プロット設定 - SDR#スタイルのヒートマップ"""
        plt.style.use('dark_background')
        
        # 2つのサブプロット：上部にリアルタイムスペクトラム、下部にウォーターフォール
        self.fig, (self.ax_spectrum, self.ax_waterfall) = plt.subplots(
            2, 1, figsize=(12, 8), facecolor='black',
            gridspec_kw={'height_ratios': [1, 2]}
        )
        
        # 上部：リアルタイムスペクトラム
        self.ax_spectrum.set_facecolor('black')
        self.line, = self.ax_spectrum.plot(self.frequencies, self.spectrum_data, 
                                           color='cyan', linewidth=1.5, alpha=0.8)
        self.highlight_line, = self.ax_spectrum.plot([], [], color='red', linewidth=3, alpha=0.9)
        
        # スペクトラム設定
        self.ax_spectrum.set_xlim(2400, 2525)
        self.ax_spectrum.set_ylim(0, 10)
        self.ax_spectrum.set_ylabel('Signal\nStrength', color='white', fontsize=10)
        self.ax_spectrum.set_title('2.4GHz Band Real-time Spectrum', color='white', fontsize=12, pad=10)
        self.ax_spectrum.tick_params(colors='white', labelsize=8)
        self.ax_spectrum.grid(True, alpha=0.3)
        
        # 周波数帯域マーキング
        self.ax_spectrum.axvspan(2400, 2483.5, alpha=0.1, color='yellow', label='WiFi')
        self.ax_spectrum.axvspan(2483.5, 2525, alpha=0.1, color='green', label='Drone')
        self.ax_spectrum.legend(loc='upper right', fontsize=8)
        
        # 下部：ウォーターフォール（ヒートマップ）
        self.ax_waterfall.set_facecolor('black')
        
        # カスタムカラーマップ（SDR#風）
        from matplotlib.colors import LinearSegmentedColormap
        colors = ['#000033', '#000066', '#0000CC', '#0066CC', '#00CCCC', 
                  '#66CC00', '#CCCC00', '#CC6600', '#CC0000', '#FFFFFF']
        n_bins = 256
        cmap = LinearSegmentedColormap.from_list('sdr', colors, N=n_bins)
        
        # ヒートマップ初期化
        self.waterfall_im = self.ax_waterfall.imshow(
            self.waterfall_data, 
            aspect='auto',
            cmap=cmap,
            interpolation='bilinear',
            extent=[2400, 2525, 0, self.waterfall_height],
            vmin=0, vmax=5
        )
        
        # ウォーターフォール設定
        self.ax_waterfall.set_xlim(2400, 2525)
        self.ax_waterfall.set_ylim(0, self.waterfall_height)
        self.ax_waterfall.set_xlabel('Frequency (MHz)', color='white', fontsize=10)
        self.ax_waterfall.set_ylabel('Time\n(newer↑)', color='white', fontsize=10)
        self.ax_waterfall.tick_params(colors='white', labelsize=8)
        
        # カラーバー追加
        cbar = self.fig.colorbar(self.waterfall_im, ax=self.ax_waterfall, 
                                orientation='vertical', shrink=0.8)
        cbar.set_label('Signal Strength', color='white', fontsize=9)
        cbar.ax.tick_params(colors='white', labelsize=7)
        
        # 周波数ガイドライン
        for freq in [2412, 2437, 2462]:  # WiFi channels 1, 6, 11
            self.ax_waterfall.axvline(freq, color='white', alpha=0.3, linewidth=0.5, linestyle='--')
        
        plt.tight_layout()
        
        # Tkinterに埋め込み
        self.canvas = FigureCanvasTkAgg(self.fig, self.plot_frame)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
    def init_gamepad(self):
        """ゲームパッド初期化"""
        try:
            pygame.init()
            pygame.joystick.init()
            
            if pygame.joystick.get_count() > 0:
                self.joystick = pygame.joystick.Joystick(0)
                self.joystick.init()
                self.pygame_initialized = True
                self.controller_var.set(f"🎮 コントローラー: {self.joystick.get_name()}")
                
                # コントローラー監視スレッド開始
                self.gamepad_thread = threading.Thread(target=self.gamepad_monitor, daemon=True)
                self.gamepad_thread.start()
            else:
                self.controller_var.set("🎮 コントローラー: 未接続")
                
        except Exception as e:
            print(f"ゲームパッド初期化エラー: {e}")
            self.controller_var.set("🎮 コントローラー: エラー")
    
    def gamepad_monitor(self):
        """コントローラー入力監視"""
        while self.pygame_initialized:
            try:
                pygame.event.pump()
                
                if self.joystick:
                    # アナログスティック (左右で周波数選択)
                    x_axis = self.joystick.get_axis(0)  # 左スティック横
                    
                    if abs(x_axis) > 0.3:  # デッドゾーン
                        # -1.0 ~ 1.0 を 2400 ~ 2525 MHz にマッピング
                        freq = 2400 + ((x_axis + 1.0) / 2.0) * 125
                        self.highlight_freq = freq
                        self.freq_info_var.set(f"注目周波数: {freq:.1f} MHz (コントローラー制御)")
                    
                    # ボタンで特定周波数にジャンプ
                    if self.joystick.get_button(0):  # Aボタン
                        self.highlight_freq = 2412  # WiFi ch1
                        self.freq_info_var.set("注目周波数: 2412 MHz (WiFi Ch1)")
                    elif self.joystick.get_button(1):  # Bボタン
                        self.highlight_freq = 2437  # WiFi ch6
                        self.freq_info_var.set("注目周波数: 2437 MHz (WiFi Ch6)")
                    elif self.joystick.get_button(2):  # Xボタン
                        self.highlight_freq = 2462  # WiFi ch11
                        self.freq_info_var.set("注目周波数: 2462 MHz (WiFi Ch11)")
                    elif self.joystick.get_button(3):  # Yボタン
                        self.highlight_freq = 2480  # ドローン帯域
                        self.freq_info_var.set("注目周波数: 2480 MHz (ドローン制御)")
                        
                time.sleep(0.05)  # 20Hz
                
            except Exception as e:
                print(f"ゲームパッド監視エラー: {e}")
                time.sleep(1)
    
    def toggle_connection(self):
        """シリアル接続切り替え"""
        if self.is_connected:
            self.disconnect_serial()
        else:
            self.connect_serial()
    
    def connect_serial(self):
        """シリアル接続"""
        try:
            print(f"シリアルポート {self.port_var.get()} に接続を試行中...")
            
            self.serial_port = serial.Serial(
                port=self.port_var.get(),
                baudrate=115200,
                timeout=1
            )
            
            print(f"シリアルポート接続成功: {self.serial_port.name}")
            
            self.is_connected = True
            self.status_var.set("🟡 接続中 - データ待機")
            self.connect_btn.config(text="切断")
            
            # シリアルポートの状態確認
            print(f"ポート状態: 開放={self.serial_port.is_open}, "
                  f"ボーレート={self.serial_port.baudrate}, "
                  f"タイムアウト={self.serial_port.timeout}")
            
            # データ受信スレッド開始
            self.serial_thread = threading.Thread(target=self.serial_monitor, daemon=True)
            self.serial_thread.start()

            # データ処理スレッド開始（パース専用）
            self.processing_thread = threading.Thread(target=self.data_processor, daemon=True)
            self.processing_thread.start()

            print("データ受信・処理スレッド開始")
            
        except Exception as e:
            print(f"シリアル接続エラー: {e}")
            messagebox.showerror("接続エラー", f"シリアルポート接続に失敗しました:\n{e}")
    
    def disconnect_serial(self):
        """シリアル切断"""
        self.is_connected = False
        if self.serial_port:
            self.serial_port.close()
        
        self.status_var.set("🔴 未接続")
        self.connect_btn.config(text="接続")
    
    def serial_monitor(self):
        """シリアルデータ監視"""
        print("シリアル監視開始")
        data_received_count = 0
        spectrum_count = 0
        
        while self.is_connected:
            try:
                if self.serial_port and self.serial_port.is_open and self.serial_port.in_waiting:
                    # UTF-8デコードエラー対策
                    try:
                        raw_data = self.serial_port.readline()
                        line = raw_data.decode('utf-8', errors='ignore').strip()
                        data_received_count += 1
                        
                        # 初回データ受信時にステータス更新
                        if data_received_count == 1:
                            print("初回データ受信確認")
                            self.status_var.set("🟢 接続完了 - データ受信中")
                        
                    except UnicodeDecodeError:
                        # デコードに失敗した場合はスキップ
                        continue
                    
                    if line.startswith("SPECTRUM:"):
                        # キューに高速投入（パース処理は別スレッドで）
                        try:
                            if not self.data_queue.full():
                                self.data_queue.put_nowait(line)
                            spectrum_count += 1
                            if spectrum_count % 20 == 0:  # 20回ごとに進捗表示
                                self.status_var.set(f"🟢 動作中 - データ: {spectrum_count}")
                        except queue.Full:
                            pass  # キューが満杯の場合はスキップ
                    else:
                        # デバッグ用：受信データを表示
                        if line and not line.startswith("=") and not line.startswith("║"):
                            print(f"受信[{data_received_count}]: {line}")
                
                time.sleep(0.005)  # 高速化 10ms→5ms
                
            except Exception as e:
                print(f"シリアル監視エラー: {e}")
                time.sleep(1)
        
        print("シリアル監視終了")

    def data_processor(self):
        """データ処理専用スレッド - 高速パース処理"""
        while self.is_connected:
            try:
                # キューからデータを取得（非ブロッキング）
                line = self.data_queue.get(timeout=0.1)

                # スペクトラムデータ解析
                try:
                    data_str = line.replace("SPECTRUM:", "")
                    values = np.fromstring(data_str, dtype=int, sep=',')

                    if len(values) == self.channels:
                        self.spectrum_data = values
                        self.data_buffer.append(self.spectrum_data.copy())

                        # ウォーターフォールデータ更新
                        self.update_waterfall_data(self.spectrum_data)

                except (ValueError, IndexError) as e:
                    print(f"データ解析エラー: {e}")

            except queue.Empty:
                continue
            except Exception as e:
                print(f"データ処理エラー: {e}")
                time.sleep(0.1)

        print("データ処理終了")

    def update_waterfall_data(self, new_spectrum):
        """ウォーターフォールデータ更新 - 高速化"""
        # 5フレームに1回だけ更新（負荷軽減）
        self.waterfall_update_counter += 1
        if self.waterfall_update_counter % 5 != 0:
            return

        # 新しいデータを履歴に追加
        self.spectrum_history.append(new_spectrum.copy())

        # ウォーターフォール配列を高速更新（numpy roll使用）
        self.waterfall_data = np.roll(self.waterfall_data, 1, axis=0)
        self.waterfall_data[0] = new_spectrum
    
    def update_plot(self, frame):
        """プロット更新 - スペクトラムとウォーターフォール - 高速化版"""
        # 上部：メインスペクトラム更新
        if len(self.data_buffer) > 0:
            # 最新データのみ使用（平均計算を省略して高速化）
            current_data = self.data_buffer[-1]

            # 軽量なガウシアンフィルタを適用（convolution省略）
            smoothed_data = current_data  # スムージング省略でさらに高速化

            self.line.set_ydata(smoothed_data)

            # Y軸調整を5フレームに1回に制限
            if frame % 5 == 0:
                max_val = np.max(smoothed_data) if np.max(smoothed_data) > 0 else 10
                self.ax_spectrum.set_ylim(0, max_val * 1.2)
        
        # ハイライト周波数の表示
        if self.highlight_freq:
            # 指定周波数周辺を強調
            freq_idx = int(self.highlight_freq - 2400)
            if 0 <= freq_idx < self.channels:
                highlight_freqs = []
                highlight_values = []
                
                # 周辺±5MHzを強調
                for i in range(max(0, freq_idx-5), min(self.channels, freq_idx+6)):
                    highlight_freqs.append(2400 + i)
                    highlight_values.append(self.spectrum_data[i] * 2)  # 2倍強調
                
                self.highlight_line.set_data(highlight_freqs, highlight_values)
                
                # ウォーターフォールにも垂直線を追加
                for line in self.ax_waterfall.lines:
                    if hasattr(line, '_highlight_line'):
                        line.remove()
                highlight_vline = self.ax_waterfall.axvline(
                    self.highlight_freq, color='red', alpha=0.8, linewidth=2, linestyle='-'
                )
                highlight_vline._highlight_line = True
        else:
            self.highlight_line.set_data([], [])
            # ハイライト線を削除
            for line in self.ax_waterfall.lines:
                if hasattr(line, '_highlight_line'):
                    line.remove()
        
        # 下部：ウォーターフォール更新 - 10フレームに1回に制限
        if len(self.spectrum_history) > 0 and frame % 10 == 0:
            # ウォーターフォールデータを上下反転（新しいデータが上に）
            display_data = np.flipud(self.waterfall_data)

            # ヒートマップ更新
            self.waterfall_im.set_array(display_data)

            # カラースケール自動調整を20フレームに1回に制限
            if frame % 20 == 0 and np.max(display_data) > 0:
                self.waterfall_im.set_clim(vmin=0, vmax=np.max(display_data) * 0.8)

        return self.line, self.highlight_line, self.waterfall_im

def main():
    root = tk.Tk()
    app = SpectrumAnalyzer(root)
    
    try:
        root.mainloop()
    except KeyboardInterrupt:
        print("アプリケーション終了")
    finally:
        if app.is_connected:
            app.disconnect_serial()
        if app.pygame_initialized:
            pygame.quit()

if __name__ == "__main__":
    main()